
### تابع : [SYTHON](https://t.me/SAYTHONH) ###

![SYTHON](https://te.legra.ph/file/80ff0951e619289e99c79.jpg)
